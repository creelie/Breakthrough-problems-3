# The Pólya–Vinogradov inequality with log log q for every character

Deep Bhattacharjee, Priyabrata Mandal and Ushashi Bhattacharya. Release v4.1.0, Zenodo 10.5281/zenodo.23881837; all versions 10.5281/zenodo.23383715.

- The repository at release v4.1.0 with its DOI recorded: paper/ (source and main.pdf, 53 pages), checks/ (C and Python checks), lean/ (Lean 4 library), figures/, dist/ (PDF, source zip, arXiv tarball).
- packages/arxiv/: the arXiv submission (PDF, source tarball compiled with pdflatex, form fields in ARXIV_SUBMISSION.md).
