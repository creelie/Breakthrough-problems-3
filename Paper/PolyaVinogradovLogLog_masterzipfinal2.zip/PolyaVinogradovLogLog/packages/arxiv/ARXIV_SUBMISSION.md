# arXiv submission: The Pólya–Vinogradov inequality with log log q for every character

Files: PolyaVinogradovLogLog_arXiv.tar.gz (upload this; main.tex, app.tex, appB.tex, figures/*.png; compiles with pdflatex, 0 errors) and PolyaVinogradovLogLog_arXiv.pdf (53 pages, for checking).

- Title: The Pólya–Vinogradov inequality with log log q for every character
- Authors: Deep Bhattacharjee, Priyabrata Mandal, Ushashi Bhattacharya
- Primary category: math.NT (Number Theory); cross-list: math.CA
- MSC class: 11L40, 11M26 (primary); 11M06, 11N36, 11R18, 11R42
- License: CC BY 4.0 (as on Hexagon)
- Comments: 53 pages, 4 figures. Improved version of Hexagon 2610.00256v3. Programs and Lean 4 sources: doi:10.5281/zenodo.23881837
- Report number, journal-ref, DOI: leave blank

Abstract (paste as is; 1041 characters, limit 1920):

Let $\chi$ be a primitive Dirichlet character modulo $q\ge3$ and let $M(\chi)$ be the largest modulus of a partial sum of $\chi$. We prove that $M(\chi)\le C\sqrt q\log\log q$ and $|L'/L(1,\chi)|\le C\log\log q$ for every such $\chi$, with an absolute constant $C$. This is the bound that Montgomery and Vaughan deduced from the generalised Riemann hypothesis, and by a theorem of Paley it is sharp up to the value of $C$. The proof combines a transfer theorem, which gives the bound for one character from a zero-free rectangle for its twists, with the zero-free half-plane $\Re s>11/12$ for all Dirichlet $L$-functions found by OpenAI, whose proof is given in full. The same half-plane bounds the Euler--Kronecker constant of $\mathbb Q(\zeta_m)$ above by $12\log m+O(\log\log m)$ for every $m$, an order known before only under the generalised Riemann hypothesis, and below by $-O(\log q\log\log q)$ for primes $q$. Without the half-plane the bounds for $M(\chi)$ and $L'/L(1,\chi)$ hold for all but $q^\varepsilon$ characters modulo $q$.
